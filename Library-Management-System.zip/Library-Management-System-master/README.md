# Library-Management-System
project based on Library management system .

Functions (Objectives)
1.To manage data across multiple users.
2.Add books.
3.Update / delete books after issued.
4.Search books among database using book name.
5.Many more.
